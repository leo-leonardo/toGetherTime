// pages/dayList/dayList.js
var myDate = new Date();
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 触摸开始时间
    touchStartTime: 0,
    // 触摸结束时间
    touchEndTime: 0,
    // 最后一次单击事件点击发生时间
    lastTapTime: 0,
    // 单击事件点击后要触发的函数
    lastTapTimeoutFunc: null,
    onelist:[],
    list:[],
    display: '',
    displaydetails: '',
    displaydetail: "",
    displayEdict: "",
    show: false,
    taskName: "",
    beizhu: "",
    selectTime: "请选择时间",
    time: "",
    selectTimelength: "点击获取任务时长",
    timeLength: "",
    selectLabel: "请选择标签",
    label: "",
    selectPrivacy: "请进行隐私设置",
    privacy: "",
    selectBegintime: "请选择开始时间",
    beginTime: "",
    selectFinishtime: "请选择结束时间",
    finishTime: "",
    selectDate: "请选择日期",
    myDate: "",
    date: "",
    newDate: "",
    newBegintime: "",
    newFinishtime: "",
    newBeizhu:"",
    newtime: "",
    curTime:"",
    newTimeLength: "",
    newPrivacy: "",
    remindtime: "",
    todayDate: "",
    labelArray: ["不紧急也不重要", "紧急但是不重要", "不紧急但是重要", "紧急并且也重要"],
    privacyArray: ["个人", "共享"],
    stateImage: "/images/toFinish.png",
    dakaIcon: "/images/_daka.png",
    state: "",
    bgColor: "white",
    todaytime: "",
    todaytitle: "",
    label: "",
    
    // lsit: [{
    //     id: 1,
    //     label: "不紧急也不重要",
    //     date: "2020-12-21",
    //     beginTime: "9:00",
    //     finishTime: "10:00",
    //     todaytitle: "听力一小时"
    //   },
    //   {
    //     id: 2,
    //     label: "紧急但是不重要",
    //     date: "2020-12-21",
    //     beginTime: "11:00",
    //     finishTime: "12:30",
    //     todaytitle: "阅读一小时"
    //   },
    //   {
    //     id: 3,
    //     label: "不紧急但是重要",
    //     date: "2020-12-21",
    //     beginTime: "14:00",
    //     finishTime: "16:00",
    //     todaytitle: "听力一小时"
    //   },
    //   {
    //     id: 4,
    //     label: "紧急并且也重要",
    //     date: "2020-12-21",
    //     beginTime: "18:00",
    //     finishTime: "19:00",
    //     todaytitle: "阅读一小时"
    //   }
    // ],
    // details: [{
    //     id: 1,
    //     remindtime: "08:50",
    //     timeLength: "30分钟",
    //     privacy: "个人",
    //     beizhu: "无"
    //   },
    //   {
    //     id: 2,

    //   }
    // ]
  },

  // 按钮触摸开始触发的事件
  touchStart: function (e) {
    this.touchStartTime = e.timeStamp
  },

  // 按钮触摸结束触发的事件
  touchEnd: function (e) {
    this.touchEndTime = e.timeStamp
  },

  /// 长按
  longTap: function (e) {
    console.log("longe", e);
    this.setData({
      taskid: e.currentTarget.dataset.taskid,
      status:e.currentTarget.dataset.status
    });
    //这里可能要从数据库传来details的数据    
    console.log("taskid", this.data.taskid)

    this.displayDetails();
  },

  /// 单击、双击
  // multipleTap: function(e) {
  //   console.log("e",e);
  //   var that = this
  //   // 控制点击事件在350ms内触发，加这层判断是为了防止长按时会触发点击事件
  //   if (that.touchEndTime - that.touchStartTime < 350) {
  //     // 当前点击的时间
  //     var currentTime = e.timeStamp
  //     var lastTapTime = that.lastTapTime
  //     // 更新最后一次点击时间
  //     that.lastTapTime = currentTime

  //     // 如果两次点击时间在300毫秒内，则认为是双击事件
  //     if (currentTime - lastTapTime < 300) {
  //       console.log("double tap")
  //       // 成功触发双击事件时，取消单击事件的执行
  //       clearTimeout(that.lastTapTimeoutFunc);
  //       wx.showModal({
  //         title: '提示',
  //         content: '双击事件被触发',
  //         showCancel: false
  //       })
  //     } else {
  //       // 单击事件延时300毫秒执行，这和最初的浏览器的点击300ms延时有点像。
  //       that.lastTapTimeoutFunc = setTimeout(function () {
  //         console.log("tap")
  //         wx.showModal({
  //           title: '提示',
  //           content: '单击事件被触发',
  //           showCancel: false
  //         })
  //       }, 300);
  //     }
  //   }
  // },

  displayDetails: function () {
    this.setData({
      displaydetails: "block",
    })
  },

  hideDetails: function () {
    this.setData({
      displaydetails: "none",
    })
  },

  displayDetail: function () {
    this.setData({
      displaydetail: "block",
    })
  },

  hideDetail: function () {
    this.setData({
      displaydetail: "none",
    })
  },

  hideEdict: function () {
    this.setData({
      displayEdict: "none",
    })
  },

  displayEdict: function () {
    this.setData({
      displayEdict: "block",
    })
  },

  showview: function () {
    this.setData({
      display: "block",
    })
  },

  hideview: function () {
    this.setData({
      display: "none",
    })
  },

  // add: function (e) {

  //   var query = {
  //     userId: 1,
  //     level: 1,
  //     taskName: this.data.taskName,
  //     //数据库还没有的数据
  //     date: this.data.myDate,
  //     startTime: this.data.myDate + "T" + this.data.myBeginTime,
  //     endTime: this.data.myDate + "T" + this.data.myFinishTime,
  //     //数据库还没有的数据
  //     remindTime: this.data.time,
  //     status: this.data.myLabel,

  //     //数据库还没有的数据
  //     privacy: this.data.myPrivacy,
  //     beizhu: this.data.beizhu,
  //   }
  //   console.log(query);
  //   wx.request({
  //     url: 'http://localhost:8085/task/create_temp_task',
  //     data: query,
  //     method: "POST",
  //     success: (result) => {
  //       console.log("result", result)
  //     },
  //     fail: (res) => {},
  //     complete: (res) => {},
  //   })

  //   //完成一系列add操作之后，关闭浮层
  //   this.hideview();
  // },

  add: function (e) {
    
    // if(this.data.myPrivacy == "个人"){
    //   this.setData({
    //     myPrivacy: 1,
    //   })
    // }else{
    //   this.setData({
    //     myPrivacy: 2,
    //   })
    // }

    if(this.data.myLabel == "紧急并且也重要"){
        this.setData({
          myLabel: 1,
        })
      }else if(this.data.myLabel == "紧急但是不重要"){
        this.setData({
          myLabel: 2,
        })
      }else if(this.data.myLabel == "不紧急但是重要"){
        this.setData({
          myLabel: 3,
        })
      }else{
        this.setData({
          myLabel: 4,
        })
      }
    var query = {
      userId: 1,
      status: 1,
      taskName: this.data.taskName,
      //数据库还没有的数据
      date: this.data.myDate,
      startTime: this.data.myDate + "T" + this.data.myBeginTime,
      endTime: this.data.myDate + "T" + this.data.myFinishTime,
      //数据库还没有的数据
 //     remindTime: this.data.time,
      level: this.data.myLabel,
      //数据库还没有的数据
      privacy: this.data.myPrivacy,
 //     beizhu: this.data.beizhu,
    }
    console.log(query);
    wx.request({
      url: 'http://www.gpy3.top:8085/task/create_temp_task',
      data: query,
      method: "POST",
      success: (result) => {
        console.log("result", result)
        wx.reLaunch({
          url: '/pages/dayList/dayList',
        })
      },
      fail: (res) => {},
      complete: (res) => {},
    })

    //完成一系列add操作之后，关闭浮层
    this.hideview();
  },

  nameInput: function (e) {
    this.setData({
      taskName: e.detail.value
    })
    console.log(this.data.taskName,"nameinput")
  },

  newnameInput:function(e){
    this.setData({
      todaytitle: e.detail.value
    })
  },

  beizhuInput: function (e) {
    this.setData({
      beizhu: e.detail.value
    })
  },

  changeBegintime: function (e) {
    let value = e.detail.value;
    this.setData({
      myBeginTime: value,
      selectBegintime: ""
    })
  },

  changeFinishtime: function (e) {
    let value = e.detail.value;
    this.setData({
      myFinishTime: value,
      selectFinishtime: ""
    })
  },

  changeNewDate: function (e) {
    let value = e.detail.value;
    this.setData({
      //newDate: value,
      date: value
    })
  },

  changeNewBegintime:function(e){
    let value = e.detail.value;
    this.setData({
      //beginTime: value,
      beginTime: value
    })
  },

  changeNewFinishtime:function(e){
    let value = e.detail.value;
    this.setData({
      //newFinishtime: value,
      finishTime: value
    })
  },

  changeNewTime:function(e){
    let value = e.detail.value;
    this.setData({
      //newtime: value,
      remindtime: value
    })
  },

  changenewLabel: function (e) {
    let i = e.detail.value;
    let value = this.data.labelArray[i];
    this.setData({
     // newlabel: value,
      label: value
    })
  },

  changenewPrivacy: function (e) {
    let i = e.detail.value;
    let value = this.data.privacyArray[i];
    this.setData({
      //newPrivacy: value,
      privacy: value
    })
  },

  newBeizhuInput:function(e){
    this.setData({
      newBeizhu: e.detail.value
    })
  },

  changeTime: function (e) {
    let value = e.detail.value;
    this.setData({
      time: value,
      selectTime: ""
    })
  },

  bindDateChange: function (e) {
    let that = this;
    that.setData({
      myDate: e.detail.value,
      selectDate: ""
    })
  },

  changeTimelength: function (e) {
    let arrayIndex = e.detail.value;
    console.log("arrayIndex", arrayIndex)
    let array = this.data.timeArray;
    let value = new Array();
    for (let i = 0; i < arrayIndex.length; i++) {
      let k = arrayIndex[i];
      console.log("k", k)
      let v = array[i][k];
      if (arrayIndex[0] == 0 && arrayIndex[1] == 0) {
        wx.showModal({
          content: '至少选择10分钟',
          showCancel: true,
          title: '警告',
          success: (result) => {},
          fail: (res) => {},
          complete: (res) => {},
        })
      } else {
        value.push(v);
        value.join(".")
        console.log("value", value)
        this.setData({
          myTimeLength: value,
          selectTimelength: ''
        })
      }
    }
  },

  changeLabel: function (e) {
    let i = e.detail.value;
    let value = this.data.labelArray[i];
    this.setData({
      myLabel: value,
      selectLabel: ""
    })
  },

  changePrivacy: function (e) {
    let i = e.detail.value;
    let value = this.data.privacyArray[i];
    this.setData({
      myPrivacy: value,
      selectPrivacy: ""
    })
  },

  buttontap(e) {
    console.log(e.detail)
  },

  gotoAdd: function (e) {
    this.showview();
  },

  gotoUpdate: function (e) {
    this.displayEdict(e);
    console.log("updatetaskid",this.data.taskid)
    let taskid=this.data.taskid;
    console.log("taskid-upd");
    let that=this;
    wx.request({
      url: 'http://www.gpy3.top:8085/task/get_task',
      data: {
        userId:1,
        taskId:taskid
      },
      method: "POST",
      success: (result) => {
        console.log("detailsresult",result)
          var list = result.data.data;
          var year=String(new Date(list[0].task.startTime).getFullYear());
          let month=new Date(list[0].task.startTime).getMonth();
          month=month+1;
          var date=String(new Date(list[0].task.startTime).getDate());
          var starhours=String(new Date(list[0].task.startTime).getHours());
          var starminutes= String(new Date(list[0].task.startTime).getMinutes());
          var endhours=String(new Date(list[0].task.endTime).getHours());
          var endminutes= String(new Date(list[0].task.endTime).getMinutes());
          var level=list[0].task.level;       

          if(month<10){
            month="0"+month
          }
          if(date<10){
            date="0"+date
          }
          if(starhours<10){
            starhours="0"+starhours
          }
          if(starminutes<10){
            starminutes="0"+starminutes
          }
          if(endhours<10){
            endhours="0"+endhours
          }
          if(endminutes<10){
            endminutes="0"+endminutes
          }
        that.setData({
          label :level,
          todaytitle :list[0].task.taskName,
          beginTime : starhours+":"+starminutes,
          date:year+"-"+month+"-"+date,
          finishTime : endhours+":"+endminutes,
          remindtime : starhours+":"+starminutes,
          privacy :list[0].task.privacy,
        })
         if(this.data.privacy== 0){
                 this.setData({
                     privacy: "个人",
                 })
               }else{
                 this.setData({
                     privacy: "共享",
                 })
               }
          if(this.data.label == 1){
                    this.setData({
                      label: "紧急并且也重要",
                    })
                  }else if(this.data.label  == 2){
                    this.setData({
                        label: "紧急但是不重要",
                    })
                  }else if(this.data.label == 3){
                    this.setData({
                        label: "不紧急但是重要",
                    })
                  }else if(this.data.label  == 4){
                    this.setData({
                        label: "不紧急但是重要",
                    })
                  }
        that.displayDetail();
        console.log("展示详情绑定的id:", taskid);
      }
      })
  },

  gotoDaka:function(e){
    // console.log("eeee",e)
    // this.setData({
    //   taskid: e.currentTarget.dataset.taskid,
    // });
    var query = {
      userId: 1,
      taskId:this.data.taskid,
      status: 2,
      
    }
      console.log("更新的query",query);
      wx.request({
        url: 'http://www.gpy3.top:8085/task/update_temp_task',
        data: query,
        method: "POST",
        success: (result) => {
          console.log("result", result)
          
          wx.reLaunch({
            url: '/pages/dayList/dayList',
          })
        },
        fail: (res) => {},
        complete: (res) => {},
      })
    
  },

//初始化页面并获取当天任务列表
  exchangeColor: function (e) {
    //获取当前日期
    var today = new Date();
    console.log("today",today);
    var month=today.getMonth()+1;
    var date=today.getDate()
    console.log(date);
    if(month<10&&date<10){
      today=today.getFullYear()+"年"+'0'+month+"月"+'0'+date+"日";  
    }
    else if(month<10&&date>9){
      today=today.getFullYear()+"年"+'0'+month+"月"+date+"日";  
    }
    else if(month>9&&date<10){
      today=today.getFullYear()+"年"+month+"月"+'0'+date+"日";  
    }
    else if(month>9&&date>9){
      today=today.getFullYear()+"年"+month+"月"+date+"日";  
    }
    
    console.log(today);
    this.setData({
      todayDate:today
    })

  

    //这里需要根据日期去获取这一天日期的任务列表
    let that=this;
    wx.request({
    //  url: 'http://localhost:8085/task/get_task',
    url: 'http://www.gpy3.top:8085/task/get_task',

      //这里需要后台的today字段
      data: {
        userId: 1,
        taskType:"ALL"
        
      },
      method: "POST",
      success(res) {
        var list = res.data.data
        for(let i=0; i<list.length; i++){

          var starhours=String(new Date(list[i].task.startTime).getHours());
          var starminutes= String(new Date(list[i].task.startTime).getMinutes());
          var endhours=String(new Date(list[i].task.endTime).getHours());
          var endminutes= String(new Date(list[i].task.endTime).getMinutes());
          var state= list[i].task.status;

          if(list[i].task.level=="1"){
            //不紧急也不重要
            list[i].task.level="#ADFEDC" 
          }
          if(list[i].task.level=="2"){
              //紧急但是不重要
              
              list[i].task.level="#BBFFFF"     
               
          }
          if(list[i].task.level=="3"){
            //不紧急但是重要
            list[i].task.level="#A6FFA6"     
          }
          if(list[i].task.level=="4"){
            //紧急并且也重要
            list[i].task.level="#97CBFF"     
          }


          if(state=="1"){
            list[i].task.status="待完成"
          }else{
          console.log(state,"!!!!!!!!")

          list[i].task.status="已完成"
            console.log(that.data.state)
          }
          if(starhours<10){
            starhours="0"+starhours
          }
          if(starminutes<10){
            starminutes="0"+starminutes
          }
          if(endhours<10){
            endhours="0"+endhours
          }
          if(endminutes<10){
            endminutes="0"+endminutes
          }
            list[i].task.startTime = starhours +":"+ starminutes
            list[i].task.endTime = endhours +":"+ endminutes
            console.log(list[i].task.startTime)
        }
        that.setData({
          onelist:list
          
        });   

        console.log("onelist",that.data.onelist)
      },
      
      fail: (res) => {},
      complete: (res) => {},
    })

    

    
    
  },

  update:function(e){
    let taskid=this.data.taskid;
    console.log(e.detail,"update-e")
//这里开始将数据传到数据库，实现update
if(this.data.privacy == "个人"){
      this.setData({
        privacy: 1,
      })
    }else{
      this.setData({
        privacy: 2,
      })
    }

    if(this.data.label == "紧急并且也重要"){
      this.setData({
        label: 1,
      })
    }else if(this.data.label == "紧急但是不重要"){
      this.setData({
        label: 2,
      })
    }else if(this.data.label == "不紧急但是重要"){
      this.setData({
        label: 3,
      })
    }else{
      this.setData({
        label: 4,
      })
    }
  var query = {
    userId: 1,
    status: 1,
    taskId:taskid,
    taskName: this.data.taskName,
    //数据库还没有的数据
    //date: this.data.myDate,
    startTime: this.data.date + "T" + this.data.beginTime,
    endTime: this.data.date + "T" + this.data.finishTime,
    //数据库还没有的数据
//     remindTime: this.data.time,
    level: this.data.label,
    //数据库还没有的数据
    ifPrivacy: this.data.privacy,
//     beizhu: this.data.beizhu,
  }
    console.log("更新的query",query);
    wx.request({
      url: 'http://www.gpy3.top:8085/task/update_temp_task',
      data: query,
      method: "POST",
      success: (result) => {
        console.log("result", result)
        wx.reLaunch({
          url: '/pages/dayList/dayList',
        })
      },
      fail: (res) => {},
      complete: (res) => {},
    })

    //完成一系列add操作之后，关闭浮层
    this.hideview();
  },




  details: function (e) {
    
    console.log("detailsid",this.data.taskid)
    let taskid=this.data.taskid;
    //这里是从数据库获取数据，展示原来的数据
    let that = this;
   
    wx.request({
      url: 'http://www.gpy3.top:8085/task/get_task',
      data: {
        userId:1,
        taskId:taskid
      },
      method: "POST",
      success: (result) => {
        console.log("detailsresult",result)
          var list = result.data.data;
          var year=String(new Date(list[0].task.startTime).getFullYear());
          let month=new Date(list[0].task.startTime).getMonth();
          month=month+1;
          var date=String(new Date(list[0].task.startTime).getDate());
          var starhours=String(new Date(list[0].task.startTime).getHours());
          var starminutes= String(new Date(list[0].task.startTime).getMinutes());
          var endhours=String(new Date(list[0].task.endTime).getHours());
          var endminutes= String(new Date(list[0].task.endTime).getMinutes());
          var level=list[0].task.level;       

          if(month<10){
            month="0"+month
          }
          if(date<10){
            date="0"+date
          }
          if(starhours<10){
            starhours="0"+starhours
          }
          if(starminutes<10){
            starminutes="0"+starminutes
          }
          if(endhours<10){
            endhours="0"+endhours
          }
          if(endminutes<10){
            endminutes="0"+endminutes
          }
        that.setData({
          label :level,
          todaytitle :list[0].task.taskName,
          beginTime : starhours+":"+starminutes,
          date:year+"-"+month+"-"+date,
          finishTime : endhours+":"+endminutes,
          remindtime : starhours+":"+starminutes,
          privacy :list[0].task.privacy,
        })
         if(this.data.privacy== 0){
                 this.setData({
                     privacy: "个人",
                 })
               }else{
                 this.setData({
                     privacy: "共享",
                 })
               }
          if(this.data.label == 1){
                    this.setData({
                      label: "紧急并且也重要",
                    })
                  }else if(this.data.label  == 2){
                    this.setData({
                        label: "紧急但是不重要",
                    })
                  }else if(this.data.label == 3){
                    this.setData({
                        label: "不紧急但是重要",
                    })
                  }else if(this.data.label  == 4){
                    this.setData({
                        label: "不紧急但是重要",
                    })
                  }
        that.displayDetail();
    
   /*  this.data.details.forEach(
      function (item, index) {
        if (id == item.id) {
          that.setData({
            todaytitle: todaytitle,
            beginTime: beginTime,
            finishTime: finishTime,
            remindtime: item.remindtime,
            label: label,
            privacy: item.privacy,
            beizhu: item.beizhu,
            date: date,
          })
          that.displayDetail();
        }
      }
    ) */
      }
      })
  },

  delete:function(e){
    let taskid=this.data.taskid;
    let that=this;
    wx.showModal({
      content: '确定要删除该任务吗？点击确定删除！',                 
      title: '提醒',
      success: function(res)  {
        if(res.confirm){
          wx.request({
            url: 'http://www.gpy3.top:8085/task/delete_task',
            data:{
              taskId:that.data.taskid
            },
            method:"GET",
            success: (result) => {
              console.log("success!!!")
              wx.reLaunch({
                url: '/pages/dayList/dayList',
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("options", options);
    this.exchangeColor();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})