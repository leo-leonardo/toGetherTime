// pages/mylist/mylist.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
    selectArray: [{
      "id": 0,
      "text": "全部"
    }, {
      "id": 1,
      "text": "未完成"
    }, {
      "id": 2,
      "text": "已完成"
    }

    ],
    list: [
      // {
      // time: "2020年2月4日",
      // finish: [{
      //   taskId: "1",
      //   taskStatus: "1",
      //   finTaskName: "我要喝牛奶",
      //   finTaskTime: "12:00-13:00"
      // },
      // {
      //   taskId: "2",
      //   taskStatus: "1",
      //   finTaskName: "我要喝牛奶",
      //   finTaskTime: "12:00-13:00"
      // }, {
      //   taskId: "3",
      //   taskStatus: "1",
      //   finTaskName: "我要喝牛奶",
      //   finTaskTime: "12:00-13:00"
      // }
      // ],
      // yet: [{
      //   taskId: "4",
      //   taskStatus: "1",
      //   yetTaskName: "我要喝牛奶",
      //   yetTaskTime: "12:00-13:00"

      // }]
      // }
    ],
    saveList: []
  },
  showDialogimage: function () {
    this.setData({
      showModal: true
    })
  },
  /**
  * 弹出框蒙层截断touchmove事件
  */
  preventTouchMove: function () {
  },
  /**
  * 隐藏模态对话框
  */
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  /**
  * 对话框取消按钮点击事件
  */
  onCancel: function () {
  
    this.hideModal();
  },
  /**
  * 对话框确认按钮点击事件
  */
  onConfirm: function () {
    var status = 2
    wx.request({
      url: 'http://www.gpy3.top:8085/task/update_temp_task',
      data:status,
      method: "POST",
      success: (result) => {
        console.log("result", result)
      },
      fail: (res) => {},
      complete: (res) => {},
    })
    //点击确认修改事件状态

    this.hideModal();
  },

  getDate: function (e) {
    // 点击未完成
    if (e.detail.id == 1) {
      let list = this.data.saveList
      list.finish = []
      console.log(list)
      this.setData({
        list: list
      })
    }
    // 点击已完成
    else if (e.detail.id == 2) {
      let list = this.data.saveList
      list.yet = []
      console.log(list)
      this.setData({
        list: list
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    var query = {
      userId: 1,
      taskType: "ALL"
    }
    wx.request({
      url: 'http://www.gpy3.top:8085/task/get_task',
      data: query,
      method: "POST",
      success: (result) => {
        console.log("result", result)
        var taskList = result.data.data
        var finList = []
        var yetList = []
        for (let i = 0; i < taskList.length; i++) {
          let result = taskList[i].task
          if (result.status == 2) {
            let task = {
              taskId: result.taskId,
              finTaskName: result.taskName,
              finTaskTime: result.startTime

            }
            finList.push(task)
          }
          if (result.status == 1) {
            let yet = {
              taskId: result.taskId,
              yetTaskName: result.taskName,
              yetTaskTime: result.startTime

            }
            yetList.push(yet)
          }
        }
        var list = [{ finish: finList, yet: yetList }]
        that.setData({
          list: list,
          saveList: list
        })
      },
      fail: (res) => { },
      complete: (res) => { },
    })


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})