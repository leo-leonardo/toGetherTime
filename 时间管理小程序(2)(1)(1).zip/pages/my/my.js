// pages/my/my.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:{},
    level:"LV1",
    slogan:"好好学习，天天向上",
    finishCount:"",
    yetCount:""
    


  },
  
   /**
   * 获取用户信息
   */
   bingGetUserInfo:function(e){
    console.log(e.detail);
    wx.login({
      success (res) {
        if (res.code) {
          console.log(res.code)
          var query ={
            username: e.detail.userInfo.nickName,
            imgUrl:e.detail.userInfo.avatarUrl,
            code:res.code

          }
          //发起网络请求
          wx.request({
            method:"POST",
            url: 'http://www.gpy3.top:8085/user/login',
            data: query,
            success (res) {
              console.log(res)
            }
            
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
    if(e.detail.userInfo){
      this.setData({
        userInfo:e.detail.userInfo
      })

    }
    },
 yet(e){
  wx.navigateTo({
    url: '/pages/yet/yet',
  })

},
finish(e){
  wx.navigateTo({
    url: '/pages/finish/finish',
  })

},
mylist(e){
  wx.reLaunch({
    url: '/pages/mylist/mylist',
  })
},
future(e){
  wx.navigateTo({
    url: '/pages/future/future',
  })
},
static(e){
  wx.navigateTo({
    url: '/pages/static/static',
  })
},
setting(e){
  wx.navigateTo({
    url: '/pages/setting/setting',
  })
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getUserInfo({
      success:(res)=>{
        console.log(res);
        this.setData({
          userInfo:res.userInfo
        })
      },
      fail:(err)=>{
        console.log(err)

      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    var query = {
      userId: 1,
      taskType: "ALL"
    }
    wx.request({
      url: 'http://www.gpy3.top:8085/task/get_task',
      data: query,
      method: "POST",
      success: (result) => {
        console.log("result", result)
        var taskList = result.data.data
        var finList = []
        var yetList = []
        for (let i = 0; i < taskList.length; i++) {
          let result = taskList[i].task
          if (result.status == 2) {
            let task = {
              taskId: result.taskId,
              finTaskName: result.taskName,
              finTaskTime: result.startTime

            }
            finList.push(task)
          }
          if (result.status == 1) {
            let yet = {
              taskId: result.taskId,
              yetTaskName: result.taskName,
              yetTaskTime: result.startTime

            }
            yetList.push(yet)
          }
        }
        console.log(finList)
        console.log(yetList)
        this.setData({
          yetCount : yetList.length,
          finishCount : finList.length
        })
      
    

        var list = [{ finish: finList, yet: yetList }]
        that.setData({
          list: list,
          saveList: list
        })
      },
      fail: (res) => { },
      complete: (res) => { },
    })

   
       

    

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})